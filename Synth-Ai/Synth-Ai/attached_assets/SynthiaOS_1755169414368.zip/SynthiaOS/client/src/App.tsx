import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Router, Route, Switch } from "wouter";
import { queryClient } from "./lib/queryClient";

// Laboratory Pages
import HomePage from "./pages/HomePage";
import PhysicsLab from "./pages/PhysicsLab";
import ChemistryLab from "./pages/ChemistryLab";
import ElectronicsLab from "./pages/ElectronicsLab";
import ComputerGraphicsLab from "./pages/ComputerGraphicsLab";
import DataStructuresLab from "./pages/DataStructuresLab";

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router>
        <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900">
          <Switch>
            <Route path="/" component={HomePage} />
            <Route path="/physics" component={PhysicsLab} />
            <Route path="/chemistry" component={ChemistryLab} />
            <Route path="/electronics" component={ElectronicsLab} />
            <Route path="/graphics" component={ComputerGraphicsLab} />
            <Route path="/data-structures" component={DataStructuresLab} />
            <Route>
              <div className="min-h-screen flex items-center justify-center text-center">
                <div className="max-w-md mx-auto p-8 bg-black/20 backdrop-blur-sm rounded-2xl border border-blue-400/30">
                  <h1 className="text-3xl font-bold text-blue-300 mb-4">404 - Laboratory Not Found</h1>
                  <p className="text-slate-200 mb-6">This laboratory module doesn't exist.</p>
                  <a 
                    href="/" 
                    className="inline-block px-6 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-semibold rounded-xl hover:from-blue-700 hover:to-indigo-700 transition-all duration-300"
                  >
                    Return to Lab Hub
                  </a>
                </div>
              </div>
            </Route>
          </Switch>
        </div>
      </Router>
    </QueryClientProvider>
  );
}

export default App;