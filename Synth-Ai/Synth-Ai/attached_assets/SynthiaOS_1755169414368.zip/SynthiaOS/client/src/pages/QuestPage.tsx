import { useState } from 'react';
import { useParams, Link } from 'wouter';
import { useQuery, useMutation } from '@tanstack/react-query';
import { ArrowLeft, Compass, CheckCircle, Lock, Star } from 'lucide-react';
import { queryClient } from '@/lib/queryClient';

interface Quest {
  id: string;
  title: string;
  description: string;
  type: string;
  status: 'available' | 'active' | 'completed' | 'locked';
  rewards: {
    vibrationBoost: number;
    clarityBoost: number;
    alignmentBoost: number;
  };
}

interface UserProfile {
  id: string;
  name: string;
  energyState: {
    vibration: number;
    clarity: number;
    alignment: number;
  };
}

export default function QuestPage() {
  const { userId } = useParams();
  const [selectedQuest, setSelectedQuest] = useState<Quest | null>(null);

  // Fetch user profile
  const { data: userProfile } = useQuery<UserProfile>({
    queryKey: ['/api/users', userId],
    enabled: !!userId
  });

  // Fetch quests
  const { data: quests = [], isLoading } = useQuery<Quest[]>({
    queryKey: ['/api/quests', userId],
    enabled: !!userId
  });

  // Complete quest mutation
  const completeQuestMutation = useMutation({
    mutationFn: async (questId: string) => {
      const response = await fetch(`/api/quests/${questId}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'completed' })
      });
      if (!response.ok) throw new Error('Failed to complete quest');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/quests', userId] });
      queryClient.invalidateQueries({ queryKey: ['/api/users', userId] });
      setSelectedQuest(null);
    }
  });

  const handleCompleteQuest = (questId: string) => {
    completeQuestMutation.mutate(questId);
  };

  const getQuestIcon = (type: string) => {
    switch (type) {
      case 'reflection': return '🧘';
      case 'creative': return '🎨';
      case 'healing': return '💚';
      case 'action': return '⚡';
      case 'exploration': return '🔮';
      default: return '✨';
    }
  };

  const getQuestColor = (type: string) => {
    switch (type) {
      case 'reflection': return 'from-violet-600/20 to-purple-700/20 border-violet-400/30';
      case 'creative': return 'from-amber-600/20 to-orange-700/20 border-amber-400/30';
      case 'healing': return 'from-emerald-600/20 to-green-700/20 border-emerald-400/30';
      case 'action': return 'from-rose-600/20 to-pink-700/20 border-rose-400/30';
      case 'exploration': return 'from-cyan-600/20 to-blue-700/20 border-cyan-400/30';
      default: return 'from-violet-600/20 to-purple-700/20 border-violet-400/30';
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen stellar-backdrop flex items-center justify-center">
        <div className="text-center">
          <Compass className="w-12 h-12 text-violet-400 animate-spin mx-auto mb-4" />
          <p className="text-purple-200">Loading your sacred quests...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen stellar-backdrop">
      {/* Header */}
      <div className="bg-black/20 backdrop-blur-sm border-b border-violet-400/20 p-4">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/" data-testid="link-back">
              <button className="p-2 rounded-xl bg-violet-600/20 border border-violet-400/30 hover:border-violet-400/60 transition-colors">
                <ArrowLeft className="w-5 h-5 text-violet-300" />
              </button>
            </Link>
            <div>
              <h1 className="text-xl font-semibold text-white">Sacred Quests</h1>
              <p className="text-purple-300/80 text-sm">
                Transform consciousness through guided experiences
              </p>
            </div>
          </div>
          
          {userProfile && (
            <div className="hidden md:flex items-center space-x-4">
              <div className="text-right text-xs">
                <div className="text-violet-300">Vibration: {userProfile.energyState.vibration}</div>
                <div className="text-amber-300">Clarity: {userProfile.energyState.clarity}</div>
                <div className="text-emerald-300">Alignment: {userProfile.energyState.alignment}</div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Quest Content */}
      <div className="max-w-4xl mx-auto p-4">
        {quests.length === 0 ? (
          <div className="text-center py-12">
            <Compass className="w-16 h-16 text-violet-400 mx-auto mb-4 animate-cosmic-pulse" />
            <h3 className="text-xl font-semibold text-violet-200 mb-2">
              Your quest journey begins
            </h3>
            <p className="text-purple-300/80 mb-4">
              Talk with Cynthia to receive personalized quests based on your spiritual needs and growth areas.
            </p>
            <Link href={`/conversation/${userId}`} data-testid="link-start-conversation">
              <button className="bg-gradient-to-r from-violet-600 to-amber-600 text-white font-semibold py-3 px-6 rounded-xl hover:from-violet-700 hover:to-amber-700 transition-all duration-300">
                Talk with Cynthia
              </button>
            </Link>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {quests.map((quest) => (
              <div
                key={quest.id}
                className={`bg-gradient-to-br ${getQuestColor(quest.type)} rounded-2xl p-6 border backdrop-blur-sm relative overflow-hidden`}
                data-testid={`quest-${quest.id}`}
              >
                {/* Quest Status Icon */}
                <div className="absolute top-4 right-4">
                  {quest.status === 'completed' && (
                    <CheckCircle className="w-6 h-6 text-green-400" />
                  )}
                  {quest.status === 'locked' && (
                    <Lock className="w-6 h-6 text-gray-400" />
                  )}
                  {quest.status === 'active' && (
                    <Star className="w-6 h-6 text-yellow-400 animate-pulse" />
                  )}
                </div>

                <div className="mb-4">
                  <div className="text-3xl mb-2">{getQuestIcon(quest.type)}</div>
                  <h3 className="text-lg font-semibold text-white mb-2">
                    {quest.title}
                  </h3>
                  <p className="text-white/80 text-sm leading-relaxed">
                    {quest.description}
                  </p>
                </div>

                {/* Rewards */}
                <div className="mb-4">
                  <h4 className="text-xs font-medium text-white/60 mb-2 uppercase tracking-wide">
                    Spiritual Rewards
                  </h4>
                  <div className="flex space-x-4 text-xs">
                    {quest.rewards.vibrationBoost > 0 && (
                      <div className="text-violet-300">
                        +{quest.rewards.vibrationBoost} Vibration
                      </div>
                    )}
                    {quest.rewards.clarityBoost > 0 && (
                      <div className="text-amber-300">
                        +{quest.rewards.clarityBoost} Clarity
                      </div>
                    )}
                    {quest.rewards.alignmentBoost > 0 && (
                      <div className="text-emerald-300">
                        +{quest.rewards.alignmentBoost} Alignment
                      </div>
                    )}
                  </div>
                </div>

                {/* Action Button */}
                <div className="mt-4">
                  {quest.status === 'available' && (
                    <button
                      onClick={() => setSelectedQuest(quest)}
                      className="w-full bg-white/10 hover:bg-white/20 text-white py-2 px-4 rounded-xl text-sm font-medium transition-colors"
                      data-testid={`button-start-quest-${quest.id}`}
                    >
                      Begin Quest
                    </button>
                  )}
                  {quest.status === 'active' && (
                    <button
                      onClick={() => handleCompleteQuest(quest.id)}
                      disabled={completeQuestMutation.isPending}
                      className="w-full bg-green-600/20 hover:bg-green-600/30 text-green-200 py-2 px-4 rounded-xl text-sm font-medium transition-colors disabled:opacity-50"
                      data-testid={`button-complete-quest-${quest.id}`}
                    >
                      Mark Complete
                    </button>
                  )}
                  {quest.status === 'completed' && (
                    <div className="w-full bg-green-600/20 text-green-200 py-2 px-4 rounded-xl text-sm font-medium text-center">
                      ✓ Completed
                    </div>
                  )}
                  {quest.status === 'locked' && (
                    <div className="w-full bg-gray-600/20 text-gray-400 py-2 px-4 rounded-xl text-sm font-medium text-center">
                      🔒 Locked
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Quest Detail Modal */}
      {selectedQuest && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="max-w-md mx-auto bg-black/80 backdrop-blur-lg rounded-2xl p-6 border border-amber-400/30">
            <div className="text-center mb-6">
              <div className="text-4xl mb-3">{getQuestIcon(selectedQuest.type)}</div>
              <h3 className="text-xl font-semibold text-white mb-2">
                {selectedQuest.title}
              </h3>
              <p className="text-white/80 leading-relaxed">
                {selectedQuest.description}
              </p>
            </div>

            <div className="mb-6">
              <h4 className="text-sm font-medium text-amber-300 mb-3">
                Sacred Intentions for this Quest:
              </h4>
              <ul className="text-sm text-white/80 space-y-2">
                <li>• Connect deeply with your inner wisdom</li>
                <li>• Allow transformation to flow naturally</li>
                <li>• Honor whatever emerges without judgment</li>
                <li>• Trust in your soul's perfect timing</li>
              </ul>
            </div>

            <div className="space-y-3">
              <button
                onClick={() => {
                  // Mark quest as active and close modal
                  fetch(`/api/quests/${selectedQuest.id}/status`, {
                    method: 'PATCH',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ status: 'active' })
                  }).then(() => {
                    queryClient.invalidateQueries({ queryKey: ['/api/quests', userId] });
                    setSelectedQuest(null);
                  });
                }}
                className="w-full bg-gradient-to-r from-violet-600 to-amber-600 text-white font-semibold py-3 px-6 rounded-xl hover:from-violet-700 hover:to-amber-700 transition-all duration-300"
                data-testid={`button-accept-quest-${selectedQuest.id}`}
              >
                Accept Sacred Quest
              </button>
              <button
                onClick={() => setSelectedQuest(null)}
                className="w-full bg-white/10 hover:bg-white/20 text-white py-2 px-4 rounded-xl text-sm font-medium transition-colors"
                data-testid="button-cancel-quest"
              >
                Maybe Later
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}