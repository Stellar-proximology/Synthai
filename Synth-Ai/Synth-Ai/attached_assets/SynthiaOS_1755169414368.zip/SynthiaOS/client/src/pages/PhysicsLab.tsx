import { useState, useEffect, useRef } from 'react';
import { Link } from 'wouter';
import { ArrowLeft, Play, Pause, RotateCcw, Settings } from 'lucide-react';

interface PendulumState {
  angle: number;
  angularVelocity: number;
  length: number;
  gravity: number;
  damping: number;
  isRunning: boolean;
}

export default function PhysicsLab() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>(0);
  const lastTimeRef = useRef<number>(0);
  
  const [pendulum, setPendulum] = useState<PendulumState>({
    angle: Math.PI / 4, // 45 degrees
    angularVelocity: 0,
    length: 200,
    gravity: 9.81,
    damping: 0.999,
    isRunning: false
  });

  const [selectedExperiment, setSelectedExperiment] = useState('pendulum');

  // Physics simulation for pendulum
  const updatePendulum = (deltaTime: number) => {
    setPendulum(prev => {
      if (!prev.isRunning) return prev;
      
      const angularAcceleration = -(prev.gravity / prev.length) * Math.sin(prev.angle);
      const newAngularVelocity = (prev.angularVelocity + angularAcceleration * deltaTime) * prev.damping;
      const newAngle = prev.angle + newAngularVelocity * deltaTime;
      
      return {
        ...prev,
        angle: newAngle,
        angularVelocity: newAngularVelocity
      };
    });
  };

  // Render pendulum simulation
  const renderPendulum = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Set up coordinate system (origin at top center)
    const centerX = canvas.width / 2;
    const centerY = 50;

    // Calculate pendulum position
    const bobX = centerX + pendulum.length * Math.sin(pendulum.angle);
    const bobY = centerY + pendulum.length * Math.cos(pendulum.angle);

    // Draw pendulum string
    ctx.beginPath();
    ctx.moveTo(centerX, centerY);
    ctx.lineTo(bobX, bobY);
    ctx.strokeStyle = '#e2e8f0';
    ctx.lineWidth = 2;
    ctx.stroke();

    // Draw pivot point
    ctx.beginPath();
    ctx.arc(centerX, centerY, 8, 0, 2 * Math.PI);
    ctx.fillStyle = '#64748b';
    ctx.fill();

    // Draw pendulum bob
    ctx.beginPath();
    ctx.arc(bobX, bobY, 20, 0, 2 * Math.PI);
    ctx.fillStyle = '#3b82f6';
    ctx.fill();
    ctx.strokeStyle = '#1e40af';
    ctx.lineWidth = 2;
    ctx.stroke();

    // Draw motion trail
    ctx.globalAlpha = 0.3;
    ctx.beginPath();
    ctx.arc(bobX, bobY, 3, 0, 2 * Math.PI);
    ctx.fillStyle = '#06b6d4';
    ctx.fill();
    ctx.globalAlpha = 1;

    // Draw angle indicator
    ctx.beginPath();
    ctx.arc(centerX, centerY, 50, Math.PI/2, Math.PI/2 + pendulum.angle, pendulum.angle > 0);
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 2;
    ctx.stroke();
  };

  // Animation loop
  const animate = (currentTime: number) => {
    const deltaTime = (currentTime - lastTimeRef.current) / 1000;
    lastTimeRef.current = currentTime;

    updatePendulum(deltaTime);
    animationRef.current = requestAnimationFrame(animate);
  };

  // Start/stop simulation
  const toggleSimulation = () => {
    setPendulum(prev => ({ ...prev, isRunning: !prev.isRunning }));
  };

  // Reset simulation
  const resetSimulation = () => {
    setPendulum(prev => ({
      ...prev,
      angle: Math.PI / 4,
      angularVelocity: 0,
      isRunning: false
    }));
  };

  // Update simulation parameters
  const updateParameter = (key: keyof PendulumState, value: number) => {
    setPendulum(prev => ({ ...prev, [key]: value }));
  };

  // Start animation when running
  useEffect(() => {
    if (pendulum.isRunning) {
      lastTimeRef.current = performance.now();
      animationRef.current = requestAnimationFrame(animate);
    } else {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    }

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [pendulum.isRunning]);

  // Render when pendulum state changes
  useEffect(() => {
    renderPendulum();
  }, [pendulum.angle, pendulum.length]);

  const experiments = [
    { id: 'pendulum', name: 'Simple Pendulum', description: 'Study oscillatory motion and period' },
    { id: 'projectile', name: 'Projectile Motion', description: 'Analyze trajectory and range' },
    { id: 'waves', name: 'Wave Interference', description: 'Explore wave superposition' },
    { id: 'optics', name: 'Optics Bench', description: 'Lens and mirror experiments' }
  ];

  return (
    <div className="min-h-screen lab-backdrop">
      {/* Header */}
      <div className="bg-black/20 backdrop-blur-sm border-b border-blue-400/20 p-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/" data-testid="link-back">
              <button className="p-2 rounded-xl bg-blue-600/20 border border-blue-400/30 hover:border-blue-400/60 transition-colors">
                <ArrowLeft className="w-5 h-5 text-blue-300" />
              </button>
            </Link>
            <div>
              <h1 className="text-2xl font-semibold text-white">Physics Laboratory</h1>
              <p className="text-slate-300 text-sm">Interactive mechanics and optics simulations</p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6 grid lg:grid-cols-4 gap-6">
        {/* Experiment Selection */}
        <div className="lg:col-span-1">
          <div className="control-panel mb-6">
            <h3 className="text-lg font-semibold text-white mb-4">Available Experiments</h3>
            <div className="space-y-2">
              {experiments.map((exp) => (
                <button
                  key={exp.id}
                  onClick={() => setSelectedExperiment(exp.id)}
                  className={`w-full text-left p-3 rounded-lg border transition-all ${
                    selectedExperiment === exp.id
                      ? 'border-blue-400/60 bg-blue-400/10'
                      : 'border-slate-600/30 hover:border-slate-500/50'
                  }`}
                  data-testid={`experiment-${exp.id}`}
                >
                  <div className="font-medium text-white">{exp.name}</div>
                  <div className="text-sm text-slate-400">{exp.description}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Simulation Controls */}
          {selectedExperiment === 'pendulum' && (
            <div className="control-panel">
              <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
                <Settings className="w-5 h-5 mr-2" />
                Pendulum Controls
              </h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Length: {pendulum.length.toFixed(0)}px
                  </label>
                  <input
                    type="range"
                    min="100"
                    max="300"
                    value={pendulum.length}
                    onChange={(e) => updateParameter('length', parseFloat(e.target.value))}
                    className="w-full"
                    data-testid="slider-length"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Initial Angle: {(pendulum.angle * 180 / Math.PI).toFixed(1)}°
                  </label>
                  <input
                    type="range"
                    min="-90"
                    max="90"
                    value={pendulum.angle * 180 / Math.PI}
                    onChange={(e) => updateParameter('angle', parseFloat(e.target.value) * Math.PI / 180)}
                    className="w-full"
                    data-testid="slider-angle"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Gravity: {pendulum.gravity.toFixed(2)} m/s²
                  </label>
                  <input
                    type="range"
                    min="1"
                    max="20"
                    step="0.1"
                    value={pendulum.gravity}
                    onChange={(e) => updateParameter('gravity', parseFloat(e.target.value))}
                    className="w-full"
                    data-testid="slider-gravity"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Damping: {(pendulum.damping * 100).toFixed(1)}%
                  </label>
                  <input
                    type="range"
                    min="90"
                    max="100"
                    step="0.1"
                    value={pendulum.damping * 100}
                    onChange={(e) => updateParameter('damping', parseFloat(e.target.value) / 100)}
                    className="w-full"
                    data-testid="slider-damping"
                  />
                </div>

                <div className="flex gap-2 mt-6">
                  <button
                    onClick={toggleSimulation}
                    className={`lab-button flex-1 ${pendulum.isRunning ? 'bg-red-600 hover:bg-red-700' : ''}`}
                    data-testid="button-toggle-simulation"
                  >
                    {pendulum.isRunning ? (
                      <>
                        <Pause className="inline w-4 h-4 mr-2" />
                        Pause
                      </>
                    ) : (
                      <>
                        <Play className="inline w-4 h-4 mr-2" />
                        Start
                      </>
                    )}
                  </button>
                  <button
                    onClick={resetSimulation}
                    className="lab-button"
                    data-testid="button-reset"
                  >
                    <RotateCcw className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Simulation Canvas */}
        <div className="lg:col-span-3">
          <div className="bg-black/30 backdrop-blur-sm rounded-2xl p-6 border border-slate-600/30">
            <h2 className="text-xl font-semibold text-white mb-4">
              {experiments.find(exp => exp.id === selectedExperiment)?.name || 'Simulation'}
            </h2>
            
            {selectedExperiment === 'pendulum' && (
              <div>
                <canvas
                  ref={canvasRef}
                  width={800}
                  height={400}
                  className="simulation-canvas w-full max-w-full"
                  data-testid="simulation-canvas"
                />
                
                <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                  <div className="bg-slate-800/50 rounded-lg p-3">
                    <div className="text-slate-400">Period</div>
                    <div className="text-white font-semibold">
                      {(2 * Math.PI * Math.sqrt(pendulum.length / (pendulum.gravity * 100))).toFixed(2)}s
                    </div>
                  </div>
                  <div className="bg-slate-800/50 rounded-lg p-3">
                    <div className="text-slate-400">Current Angle</div>
                    <div className="text-white font-semibold">
                      {(pendulum.angle * 180 / Math.PI).toFixed(1)}°
                    </div>
                  </div>
                  <div className="bg-slate-800/50 rounded-lg p-3">
                    <div className="text-slate-400">Angular Velocity</div>
                    <div className="text-white font-semibold">
                      {pendulum.angularVelocity.toFixed(3)} rad/s
                    </div>
                  </div>
                  <div className="bg-slate-800/50 rounded-lg p-3">
                    <div className="text-slate-400">Energy</div>
                    <div className="text-white font-semibold">
                      {(0.5 * pendulum.angularVelocity ** 2 + pendulum.gravity * (1 - Math.cos(pendulum.angle))).toFixed(3)} J
                    </div>
                  </div>
                </div>

                <div className="mt-4 bg-blue-900/20 rounded-lg p-4 border border-blue-400/20">
                  <h3 className="font-semibold text-blue-300 mb-2">Physics Concepts</h3>
                  <ul className="text-sm text-slate-300 space-y-1">
                    <li>• Simple harmonic motion for small angles (θ &lt; 15°)</li>
                    <li>• Period formula: T = 2π√(L/g)</li>
                    <li>• Conservation of energy: KE + PE = constant</li>
                    <li>• Damping effects reduce amplitude over time</li>
                  </ul>
                </div>
              </div>
            )}

            {selectedExperiment !== 'pendulum' && (
              <div className="text-center py-20">
                <div className="text-6xl mb-4">🚧</div>
                <h3 className="text-xl font-semibold text-white mb-2">Coming Soon</h3>
                <p className="text-slate-400">
                  This experiment is under development. Try the pendulum simulation for now!
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}