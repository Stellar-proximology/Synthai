import { Link } from 'wouter';
import { ArrowLeft, Monitor } from 'lucide-react';

export default function ComputerGraphicsLab() {
  return (
    <div className="min-h-screen lab-backdrop">
      <div className="bg-black/20 backdrop-blur-sm border-b border-purple-400/20 p-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/" data-testid="link-back">
              <button className="p-2 rounded-xl bg-purple-600/20 border border-purple-400/30 hover:border-purple-400/60 transition-colors">
                <ArrowLeft className="w-5 h-5 text-purple-300" />
              </button>
            </Link>
            <div>
              <h1 className="text-2xl font-semibold text-white">Computer Graphics Lab</h1>
              <p className="text-slate-300 text-sm">2D/3D graphics algorithms and rendering</p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6 text-center">
        <div className="bg-black/30 backdrop-blur-sm rounded-2xl p-12 border border-purple-400/30">
          <Monitor className="w-24 h-24 text-purple-400 mx-auto mb-6" />
          <h2 className="text-3xl font-bold text-white mb-4">Coming Soon</h2>
          <p className="text-slate-300 text-lg mb-6">
            Computer graphics simulations are under development. Features will include:
          </p>
          <ul className="text-left max-w-md mx-auto space-y-2 text-slate-300">
            <li>• 2D transformation matrices</li>
            <li>• 3D rendering pipeline</li>
            <li>• Ray tracing demonstrations</li>
            <li>• Fractal generation algorithms</li>
          </ul>
        </div>
      </div>
    </div>
  );
}