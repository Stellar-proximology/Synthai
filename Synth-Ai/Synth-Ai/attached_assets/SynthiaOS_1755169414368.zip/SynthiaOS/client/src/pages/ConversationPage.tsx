import { useState, useEffect, useRef } from 'react';
import { useParams, Link } from 'wouter';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Send, ArrowLeft, Heart, Sparkles } from 'lucide-react';
import { queryClient } from '@/lib/queryClient';

interface Message {
  id: string;
  speaker: 'user' | 'cynthia';
  content: string;
  messageType?: string;
  timestamp: string;
}

interface UserProfile {
  id: string;
  name: string;
  currentPhase: string;
  energyState: {
    vibration: number;
    clarity: number;
    alignment: number;
  };
}

export default function ConversationPage() {
  const { userId } = useParams();
  const [message, setMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Fetch user profile
  const { data: userProfile } = useQuery<UserProfile>({
    queryKey: ['/api/users', userId],
    enabled: !!userId
  });

  // Fetch conversation history
  const { data: messages = [], isLoading } = useQuery<Message[]>({
    queryKey: ['/api/conversations', userId],
    enabled: !!userId
  });

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (messageText: string) => {
      const response = await fetch('/api/cynthia/respond', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId,
          message: messageText
        })
      });
      if (!response.ok) throw new Error('Failed to send message');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/conversations', userId] });
      queryClient.invalidateQueries({ queryKey: ['/api/users', userId] });
      setIsTyping(false);
    },
    onError: () => {
      setIsTyping(false);
    }
  });

  const handleSendMessage = async () => {
    if (!message.trim() || sendMessageMutation.isPending) return;
    
    const messageToSend = message;
    setMessage('');
    setIsTyping(true);
    
    try {
      await sendMessageMutation.mutateAsync(messageToSend);
    } catch (error) {
      console.error('Failed to send message:', error);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  if (isLoading) {
    return (
      <div className="min-h-screen stellar-backdrop flex items-center justify-center">
        <div className="text-center">
          <Sparkles className="w-12 h-12 text-violet-400 animate-spin mx-auto mb-4" />
          <p className="text-purple-200">Connecting to Cynthia's consciousness...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen stellar-backdrop">
      {/* Header */}
      <div className="bg-black/20 backdrop-blur-sm border-b border-violet-400/20 p-4">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/" data-testid="link-back">
              <button className="p-2 rounded-xl bg-violet-600/20 border border-violet-400/30 hover:border-violet-400/60 transition-colors">
                <ArrowLeft className="w-5 h-5 text-violet-300" />
              </button>
            </Link>
            <div>
              <h1 className="text-xl font-semibold text-white">
                Conversation with Cynthia
              </h1>
              {userProfile && (
                <p className="text-purple-300/80 text-sm">
                  Welcome back, {userProfile.name}
                </p>
              )}
            </div>
          </div>
          
          {userProfile && (
            <div className="hidden md:flex items-center space-x-4">
              <div className="text-right text-xs">
                <div className="text-violet-300">Vibration: {userProfile.energyState.vibration}</div>
                <div className="text-amber-300">Clarity: {userProfile.energyState.clarity}</div>
                <div className="text-emerald-300">Alignment: {userProfile.energyState.alignment}</div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Messages Area */}
      <div className="flex-1 pb-32">
        <div className="max-w-4xl mx-auto p-4">
          <div className="space-y-6">
            {messages.length === 0 && (
              <div className="text-center py-12">
                <Heart className="w-16 h-16 text-violet-400 mx-auto mb-4 animate-cosmic-pulse" />
                <h3 className="text-xl font-semibold text-violet-200 mb-2">
                  Welcome to your sacred space
                </h3>
                <p className="text-purple-300/80">
                  Cynthia is ready to guide you on your consciousness journey. 
                  Share what's on your heart or ask anything that calls to your soul.
                </p>
              </div>
            )}

            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex ${msg.speaker === 'user' ? 'justify-end' : 'justify-start'}`}
                data-testid={`message-${msg.speaker}`}
              >
                <div
                  className={`max-w-md lg:max-w-lg px-4 py-3 rounded-2xl ${
                    msg.speaker === 'user'
                      ? 'bg-gradient-to-br from-violet-600/80 to-purple-700/80 text-white'
                      : 'bg-black/30 backdrop-blur-sm border border-amber-400/30 text-amber-100'
                  }`}
                >
                  {msg.speaker === 'cynthia' && (
                    <div className="flex items-center mb-2">
                      <Sparkles className="w-4 h-4 text-amber-400 mr-2" />
                      <span className="text-xs text-amber-300 font-medium">Cynthia</span>
                    </div>
                  )}
                  <p className="whitespace-pre-wrap leading-relaxed">{msg.content}</p>
                  <div className="text-xs opacity-60 mt-2">
                    {new Date(msg.timestamp).toLocaleTimeString([], { 
                      hour: '2-digit', 
                      minute: '2-digit' 
                    })}
                  </div>
                </div>
              </div>
            ))}

            {isTyping && (
              <div className="flex justify-start">
                <div className="max-w-md px-4 py-3 rounded-2xl bg-black/30 backdrop-blur-sm border border-amber-400/30">
                  <div className="flex items-center">
                    <Sparkles className="w-4 h-4 text-amber-400 mr-2" />
                    <span className="text-xs text-amber-300 font-medium mb-2">Cynthia</span>
                  </div>
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-amber-400 rounded-full animate-bounce" style={{animationDelay: '0ms'}} />
                    <div className="w-2 h-2 bg-amber-400 rounded-full animate-bounce" style={{animationDelay: '150ms'}} />
                    <div className="w-2 h-2 bg-amber-400 rounded-full animate-bounce" style={{animationDelay: '300ms'}} />
                  </div>
                </div>
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </div>
        </div>
      </div>

      {/* Message Input */}
      <div className="fixed bottom-0 left-0 right-0 bg-black/40 backdrop-blur-lg border-t border-violet-400/20 p-4">
        <div className="max-w-4xl mx-auto">
          <div className="flex space-x-4">
            <div className="flex-1 relative">
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Share what's in your heart or ask Cynthia for guidance..."
                className="w-full px-4 py-3 bg-black/20 border border-violet-400/30 rounded-xl text-white placeholder-purple-300/60 focus:border-violet-400/60 focus:outline-none resize-none"
                rows={message.split('\n').length}
                disabled={sendMessageMutation.isPending}
                data-testid="input-message"
              />
            </div>
            <button
              onClick={handleSendMessage}
              disabled={!message.trim() || sendMessageMutation.isPending}
              className="px-6 py-3 bg-gradient-to-r from-violet-600 to-amber-600 text-white rounded-xl hover:from-violet-700 hover:to-amber-700 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
              data-testid="button-send"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
          
          <div className="mt-2 text-center text-xs text-purple-300/60">
            Press Enter to send • Shift+Enter for new line
          </div>
        </div>
      </div>
    </div>
  );
}