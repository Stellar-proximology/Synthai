import { Link } from 'wouter';
import { 
  Atom, 
  Zap, 
  Monitor, 
  Database, 
  Calculator,
  Beaker,
  Microscope,
  Play
} from 'lucide-react';

export default function HomePage() {
  const laboratories = [
    {
      id: 'physics',
      name: 'Physics Laboratory',
      description: 'Mechanics, optics, waves, and thermodynamics simulations',
      icon: Atom,
      color: 'from-blue-500 to-cyan-500',
      borderColor: 'border-blue-400/30 hover:border-blue-400/60',
      experiments: ['Pendulum Motion', 'Wave Interference', 'Optics Bench', 'Projectile Motion']
    },
    {
      id: 'chemistry',
      name: 'Chemistry Laboratory',
      description: 'Molecular visualization, reactions, and titration experiments',
      icon: Beaker,
      color: 'from-green-500 to-emerald-500',
      borderColor: 'border-green-400/30 hover:border-green-400/60',
      experiments: ['Molecular Models', 'pH Titration', 'Reaction Kinetics', 'Periodic Table']
    },
    {
      id: 'electronics',
      name: 'Electronics Laboratory',
      description: 'Circuit simulation, digital logic, and component testing',
      icon: Zap,
      color: 'from-yellow-500 to-orange-500',
      borderColor: 'border-yellow-400/30 hover:border-yellow-400/60',
      experiments: ['Circuit Builder', 'Logic Gates', 'Oscilloscope', 'Component Tester']
    },
    {
      id: 'graphics',
      name: 'Computer Graphics Lab',
      description: '2D/3D graphics algorithms, transformations, and rendering',
      icon: Monitor,
      color: 'from-purple-500 to-pink-500',
      borderColor: 'border-purple-400/30 hover:border-purple-400/60',
      experiments: ['2D Transforms', '3D Rendering', 'Ray Tracing', 'Fractals']
    },
    {
      id: 'data-structures',
      name: 'Data Structures Lab',
      description: 'Algorithm visualization, sorting, and data structure demos',
      icon: Database,
      color: 'from-indigo-500 to-blue-500',
      borderColor: 'border-indigo-400/30 hover:border-indigo-400/60',
      experiments: ['Sorting Algorithms', 'Tree Traversal', 'Graph Theory', 'Queue Animation']
    }
  ];

  return (
    <div className="min-h-screen lab-backdrop">
      {/* Header */}
      <div className="bg-black/20 backdrop-blur-sm border-b border-blue-400/20 p-6">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-4xl md:text-5xl font-bold lab-text-gradient mb-4">
            Virtual Laboratory Platform
          </h1>
          <p className="text-xl text-slate-300 max-w-3xl">
            Interactive scientific simulations and experiments for educational learning. 
            Explore physics, chemistry, electronics, and computer science through hands-on virtual labs.
          </p>
        </div>
      </div>

      {/* Laboratory Grid */}
      <div className="max-w-7xl mx-auto p-6">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {laboratories.map((lab) => {
            const IconComponent = lab.icon;
            return (
              <Link key={lab.id} href={`/${lab.id}`} className="block group">
                <div className={`bg-black/30 backdrop-blur-sm rounded-2xl p-6 border ${lab.borderColor} transition-all duration-300 hover:scale-105 lab-glow`}>
                  {/* Lab Icon */}
                  <div className={`w-16 h-16 bg-gradient-to-br ${lab.color} rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
                    <IconComponent className="w-8 h-8 text-white" />
                  </div>

                  {/* Lab Info */}
                  <h3 className="text-xl font-semibold text-white mb-3">
                    {lab.name}
                  </h3>
                  <p className="text-slate-300 mb-4 leading-relaxed">
                    {lab.description}
                  </p>

                  {/* Quick Experiments List */}
                  <div className="space-y-2">
                    <h4 className="text-sm font-medium text-slate-400 uppercase tracking-wide">
                      Featured Experiments
                    </h4>
                    <div className="grid grid-cols-2 gap-2">
                      {lab.experiments.map((experiment, index) => (
                        <div 
                          key={index}
                          className="text-xs bg-white/10 rounded-lg px-2 py-1 text-slate-300"
                        >
                          {experiment}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Enter Lab Button */}
                  <div className="mt-6">
                    <div className={`lab-button w-full text-center bg-gradient-to-r ${lab.color} opacity-80 group-hover:opacity-100 transition-opacity duration-300`}>
                      <Play className="inline w-4 h-4 mr-2" />
                      Enter Laboratory
                    </div>
                  </div>
                </div>
              </Link>
            );
          })}
        </div>

        {/* Platform Features */}
        <div className="bg-black/30 backdrop-blur-sm rounded-2xl p-8 border border-slate-600/30">
          <h2 className="text-2xl font-bold text-white mb-6 flex items-center">
            <Microscope className="w-6 h-6 mr-3 text-blue-400" />
            Platform Features
          </h2>
          
          <div className="grid md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="w-12 h-12 bg-blue-500/20 rounded-xl flex items-center justify-center mb-4 mx-auto">
                <Calculator className="w-6 h-6 text-blue-400" />
              </div>
              <h3 className="font-semibold text-white mb-2">Interactive Simulations</h3>
              <p className="text-slate-400 text-sm">
                Real-time physics engines, molecular visualizations, and circuit simulators
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 bg-green-500/20 rounded-xl flex items-center justify-center mb-4 mx-auto">
                <Monitor className="w-6 h-6 text-green-400" />
              </div>
              <h3 className="font-semibold text-white mb-2">Browser-Native</h3>
              <p className="text-slate-400 text-sm">
                HTML5 Canvas and WebGL rendering - no plugins required, works on mobile
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 bg-purple-500/20 rounded-xl flex items-center justify-center mb-4 mx-auto">
                <Database className="w-6 h-6 text-purple-400" />
              </div>
              <h3 className="font-semibold text-white mb-2">Educational Focus</h3>
              <p className="text-slate-400 text-sm">
                Step-by-step experiments with explanations and interactive controls
              </p>
            </div>
          </div>
        </div>

        {/* Quick Start */}
        <div className="mt-8 text-center">
          <p className="text-slate-400 mb-4">
            New to virtual laboratories? Start with Physics Lab for fundamental simulations.
          </p>
          <Link href="/physics">
            <button className="lab-button">
              <Play className="inline w-4 h-4 mr-2" />
              Start with Physics Lab
            </button>
          </Link>
        </div>
      </div>
    </div>
  );
}