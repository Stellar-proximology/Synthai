import { useParams, Link } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { ArrowLeft, MapPin, Zap, Eye, Heart } from 'lucide-react';

interface UserProfile {
  id: string;
  name: string;
  currentPhase: string;
  energyState: {
    vibration: number;
    clarity: number;
    alignment: number;
  };
  preferences: {
    cosmicTheme: string;
    interactionStyle: string;
  };
}

interface WorldState {
  id: string;
  currentZone: string;
  weather: string;
  timeOfDay: string;
  unlockedZones: string[];
  ambientColors: {
    primary: string;
    secondary: string;
    accent: string;
  };
}

export default function WorldPage() {
  const { userId } = useParams();

  // Fetch user profile
  const { data: userProfile, isLoading: profileLoading } = useQuery<UserProfile>({
    queryKey: ['/api/users', userId],
    enabled: !!userId
  });

  // Fetch world state
  const { data: worldState, isLoading: worldLoading } = useQuery<WorldState>({
    queryKey: ['/api/world-state', userId],
    enabled: !!userId
  });

  const isLoading = profileLoading || worldLoading;

  const getPhaseDescription = (phase: string) => {
    switch (phase) {
      case 'initial':
        return 'Beginning your consciousness journey with Cynthia';
      case 'interview':
        return 'Exploring your spiritual foundations through dialogue';
      case 'vision':
        return 'Receiving visions and insights about your path';
      case 'incubation':
        return 'Integrating wisdom through transformative experiences';
      case 'journey':
        return 'Actively navigating your expanded consciousness';
      default:
        return 'Exploring the depths of awareness';
    }
  };

  const getEnergyColor = (value: number) => {
    if (value >= 80) return 'text-green-400';
    if (value >= 60) return 'text-yellow-400';
    if (value >= 40) return 'text-orange-400';
    return 'text-red-400';
  };

  const getEnergyBarWidth = (value: number) => `${value}%`;

  const zones = [
    {
      id: 'sanctuary',
      name: 'Sacred Sanctuary',
      description: 'Your starting point of spiritual safety and connection',
      icon: '🏛️',
      unlocked: true
    },
    {
      id: 'reflection-pool',
      name: 'Reflection Pool',
      description: 'Deep waters of contemplation and inner wisdom',
      icon: '🌊',
      unlocked: worldState?.unlockedZones.includes('reflection-pool') || false
    },
    {
      id: 'vision-grove',
      name: 'Vision Grove',
      description: 'Ancient trees holding messages from your highest self',
      icon: '🌳',
      unlocked: worldState?.unlockedZones.includes('vision-grove') || false
    },
    {
      id: 'crystal-caves',
      name: 'Crystal Caves',
      description: 'Crystalline chambers of transformation and healing',
      icon: '💎',
      unlocked: worldState?.unlockedZones.includes('crystal-caves') || false
    },
    {
      id: 'star-bridge',
      name: 'Star Bridge',
      description: 'Bridge between dimensions where cosmic wisdom flows',
      icon: '🌌',
      unlocked: worldState?.unlockedZones.includes('star-bridge') || false
    }
  ];

  if (isLoading) {
    return (
      <div className="min-h-screen stellar-backdrop flex items-center justify-center">
        <div className="text-center">
          <MapPin className="w-12 h-12 text-violet-400 animate-spin mx-auto mb-4" />
          <p className="text-purple-200">Manifesting your universe...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen stellar-backdrop">
      {/* Header */}
      <div className="bg-black/20 backdrop-blur-sm border-b border-violet-400/20 p-4">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/" data-testid="link-back">
              <button className="p-2 rounded-xl bg-violet-600/20 border border-violet-400/30 hover:border-violet-400/60 transition-colors">
                <ArrowLeft className="w-5 h-5 text-violet-300" />
              </button>
            </Link>
            <div>
              <h1 className="text-xl font-semibold text-white">Your Universe</h1>
              <p className="text-purple-300/80 text-sm">
                Consciousness landscape and spiritual progress
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto p-4 space-y-8">
        {/* Spiritual Profile Overview */}
        {userProfile && (
          <div className="bg-black/30 backdrop-blur-sm rounded-2xl p-6 border border-violet-400/20">
            <h2 className="text-2xl font-semibold cosmic-text-gradient mb-4">
              {userProfile.name}'s Consciousness Profile
            </h2>
            
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="text-lg font-medium text-violet-200 mb-3">Current Phase</h3>
                <div className="bg-violet-600/20 rounded-xl p-4 border border-violet-400/30">
                  <div className="text-2xl font-semibold text-white capitalize mb-1">
                    {userProfile.currentPhase}
                  </div>
                  <div className="text-violet-300/80 text-sm">
                    {getPhaseDescription(userProfile.currentPhase)}
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium text-violet-200 mb-3">Spiritual Preferences</h3>
                <div className="space-y-2">
                  <div className="bg-amber-600/20 rounded-xl p-3 border border-amber-400/30">
                    <div className="text-sm text-amber-300 font-medium">Cosmic Theme</div>
                    <div className="text-white capitalize">{userProfile.preferences.cosmicTheme}</div>
                  </div>
                  <div className="bg-emerald-600/20 rounded-xl p-3 border border-emerald-400/30">
                    <div className="text-sm text-emerald-300 font-medium">Guidance Style</div>
                    <div className="text-white capitalize">{userProfile.preferences.interactionStyle}</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Energy State */}
        {userProfile && (
          <div className="bg-black/30 backdrop-blur-sm rounded-2xl p-6 border border-violet-400/20">
            <h2 className="text-xl font-semibold text-white mb-4 flex items-center">
              <Zap className="w-5 h-5 text-yellow-400 mr-2" />
              Energy State
            </h2>
            
            <div className="space-y-4">
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-violet-300 font-medium">Vibration</span>
                  <span className={`font-semibold ${getEnergyColor(userProfile.energyState.vibration)}`}>
                    {userProfile.energyState.vibration}/100
                  </span>
                </div>
                <div className="bg-black/40 rounded-full h-3 overflow-hidden">
                  <div 
                    className="bg-gradient-to-r from-violet-500 to-purple-600 h-full transition-all duration-500"
                    style={{ width: getEnergyBarWidth(userProfile.energyState.vibration) }}
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-amber-300 font-medium">Clarity</span>
                  <span className={`font-semibold ${getEnergyColor(userProfile.energyState.clarity)}`}>
                    {userProfile.energyState.clarity}/100
                  </span>
                </div>
                <div className="bg-black/40 rounded-full h-3 overflow-hidden">
                  <div 
                    className="bg-gradient-to-r from-amber-500 to-orange-600 h-full transition-all duration-500"
                    style={{ width: getEnergyBarWidth(userProfile.energyState.clarity) }}
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-emerald-300 font-medium">Alignment</span>
                  <span className={`font-semibold ${getEnergyColor(userProfile.energyState.alignment)}`}>
                    {userProfile.energyState.alignment}/100
                  </span>
                </div>
                <div className="bg-black/40 rounded-full h-3 overflow-hidden">
                  <div 
                    className="bg-gradient-to-r from-emerald-500 to-green-600 h-full transition-all duration-500"
                    style={{ width: getEnergyBarWidth(userProfile.energyState.alignment) }}
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Consciousness Zones */}
        <div className="bg-black/30 backdrop-blur-sm rounded-2xl p-6 border border-violet-400/20">
          <h2 className="text-xl font-semibold text-white mb-4 flex items-center">
            <MapPin className="w-5 h-5 text-cyan-400 mr-2" />
            Consciousness Zones
          </h2>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {zones.map((zone) => (
              <div
                key={zone.id}
                className={`rounded-xl p-4 border transition-all ${
                  zone.unlocked
                    ? worldState?.currentZone === zone.id
                      ? 'bg-cyan-600/30 border-cyan-400/60 ring-2 ring-cyan-400/30'
                      : 'bg-cyan-600/10 border-cyan-400/30 hover:border-cyan-400/50'
                    : 'bg-gray-600/10 border-gray-500/30'
                }`}
                data-testid={`zone-${zone.id}`}
              >
                <div className="text-center">
                  <div className={`text-3xl mb-2 ${zone.unlocked ? '' : 'opacity-50'}`}>
                    {zone.icon}
                  </div>
                  <h3 className={`font-semibold mb-2 ${
                    zone.unlocked ? 'text-white' : 'text-gray-400'
                  }`}>
                    {zone.name}
                  </h3>
                  <p className={`text-xs leading-relaxed ${
                    zone.unlocked ? 'text-cyan-300/80' : 'text-gray-500'
                  }`}>
                    {zone.description}
                  </p>
                  
                  {worldState?.currentZone === zone.id && (
                    <div className="mt-3 text-xs bg-cyan-400/20 text-cyan-300 py-1 px-2 rounded-full">
                      Current Location
                    </div>
                  )}
                  
                  {!zone.unlocked && (
                    <div className="mt-3 text-xs bg-gray-500/20 text-gray-400 py-1 px-2 rounded-full">
                      🔒 Locked
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-6 text-center">
            <p className="text-purple-300/80 text-sm">
              Unlock new zones by deepening your conversations with Cynthia and completing sacred quests
            </p>
          </div>
        </div>

        {/* Current Environment */}
        {worldState && (
          <div className="bg-black/30 backdrop-blur-sm rounded-2xl p-6 border border-violet-400/20">
            <h2 className="text-xl font-semibold text-white mb-4 flex items-center">
              <Eye className="w-5 h-5 text-purple-400 mr-2" />
              Current Environment
            </h2>
            
            <div className="grid md:grid-cols-3 gap-4">
              <div className="bg-purple-600/20 rounded-xl p-4 border border-purple-400/30">
                <h4 className="text-purple-300 font-medium mb-2">Weather</h4>
                <div className="text-white capitalize">
                  {worldState.weather.replace('-', ' ')}
                </div>
              </div>
              
              <div className="bg-amber-600/20 rounded-xl p-4 border border-amber-400/30">
                <h4 className="text-amber-300 font-medium mb-2">Time of Day</h4>
                <div className="text-white capitalize">
                  {worldState.timeOfDay.replace('-', ' ')}
                </div>
              </div>
              
              <div className="bg-emerald-600/20 rounded-xl p-4 border border-emerald-400/30">
                <h4 className="text-emerald-300 font-medium mb-2">Unlocked Zones</h4>
                <div className="text-white">
                  {worldState.unlockedZones.length} of {zones.length}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Quick Actions */}
        <div className="grid md:grid-cols-2 gap-4">
          <Link href={`/conversation/${userId}`} data-testid="link-continue-conversation">
            <div className="bg-gradient-to-br from-violet-600/20 to-purple-700/20 rounded-2xl p-6 border border-violet-400/30 hover:border-violet-400/60 transition-all duration-300 hover:scale-105 text-center">
              <Heart className="w-8 h-8 text-violet-300 mb-4 mx-auto" />
              <h3 className="text-lg font-semibold text-violet-200 mb-2">
                Continue with Cynthia
              </h3>
              <p className="text-violet-300/80 text-sm">
                Deepen your spiritual dialogue and receive personalized guidance
              </p>
            </div>
          </Link>
          
          <Link href={`/quests/${userId}`} data-testid="link-explore-quests">
            <div className="bg-gradient-to-br from-amber-600/20 to-orange-700/20 rounded-2xl p-6 border border-amber-400/30 hover:border-amber-400/60 transition-all duration-300 hover:scale-105 text-center">
              <MapPin className="w-8 h-8 text-amber-300 mb-4 mx-auto" />
              <h3 className="text-lg font-semibold text-amber-200 mb-2">
                Explore Sacred Quests
              </h3>
              <p className="text-amber-300/80 text-sm">
                Discover new transformative experiences and spiritual challenges
              </p>
            </div>
          </Link>
        </div>
      </div>
    </div>
  );
}