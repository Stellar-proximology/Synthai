#!/bin/bash
echo "🌌 Starting YOU-N-I-VERSE consciousness simulation..."
echo "🌟 Initializing Cynthia AI agent with Tiny Llama..."

# Start backend server
tsx server/index.ts &
SERVER_PID=$!

# Wait for server to start
sleep 3

# Start frontend development server
cd client && npx vite --host 0.0.0.0 --port 5173 &
CLIENT_PID=$!

echo "✨ YOU-N-I-VERSE is running:"
echo "   Backend: http://localhost:3001"
echo "   Frontend: http://localhost:5173"
echo "   Health check: http://localhost:3001/health"

# Wait for both processes
wait $SERVER_PID
wait $CLIENT_PID