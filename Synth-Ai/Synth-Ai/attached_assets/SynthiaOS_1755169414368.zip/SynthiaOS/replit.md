# Overview

VIRTUAL LABORATORY PLATFORM - An interactive virtual laboratory environment featuring multiple scientific simulations and experiments. The platform provides physics, chemistry, computer graphics, and electronics virtual labs accessible through a modern web interface. Built with HTML5, JavaScript, and CSS3 for browser-native compatibility across all devices.

## Current Status (August 13, 2025)
🚀 **BUILDING VIRTUAL LABORATORY** - Interactive simulation platform for educational experiments
- Architecture: HTML5/JavaScript-based virtual lab environment
- Target: Multi-subject laboratory simulations (Physics, Chemistry, Electronics, Computer Graphics)
- Design: Browser-native with mobile-responsive interface
- Inspiration: GitHub virtual-laboratory repositories and lab.js platform

## Planned Laboratory Modules
- **Physics Lab**: Mechanics simulations, optics experiments, fluid dynamics
- **Chemistry Lab**: Molecular visualization, reaction simulations, titration experiments  
- **Electronics Lab**: Circuit simulation, digital logic design, component testing
- **Computer Graphics Lab**: 2D/3D graphics algorithms, transformations, rendering
- **Data Structures Lab**: Algorithm visualization, queue animations, sorting demos
- **General Lab Tools**: Calculators, measurement tools, data analysis

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Core Application Structure
The system is designed as a web-based interactive simulator with the following key architectural components:

**Frontend Architecture**: Built as a responsive web application to deliver an immersive, game-like experience with dynamic visual elements that respond to user choices and energy states.

**AI-Driven Personalization Engine**: Cynthia serves as the central consciousness that conducts spiritual interviews and processes user responses to generate personalized content, storylines, and experiences.

**Consciousness Exploration System**: The system focuses on spiritual growth through guided conversations, symbolic life events, and transformative quests rather than specific Human Design frameworks.

**Dynamic Content Generation**: The application generates personalized quests, challenges, symbolic life events, and environmental changes (weather, colors, zones) based on the user's spiritual journey and responses to Cynthia's guidance.

**Progressive Experience System**: Users advance through different phases including initial profiling, vision presentation, incubation lab experiences, and symbolic life events with unlockable content.

## Data Architecture
**User Profile System**: Stores spiritual journey data, consciousness exploration progress, and personalized experience preferences.

**Content Management**: Manages dynamic storylines, quest templates, NPC characters, and environmental assets that adapt based on user profiles.

**Session Management**: Tracks user interactions with Cynthia, decision patterns, and progress through various simulation phases.

# External Dependencies

**Human Design Data Sources**: Integration with Human Design calculation systems for generating accurate profiles and cross-based paths.

**AI/LLM Services**: Backend AI services to power Cynthia's conversational abilities and personalized content generation.

**Media Assets**: External libraries for visual effects, environmental graphics, and audio elements that create the immersive simulation experience.

**Analytics Platform**: User interaction tracking to refine personalization algorithms and improve the simulation experience.