import { z } from "zod";

// User spiritual journey profile
export const userProfileSchema = z.object({
  id: z.string(),
  name: z.string(),
  currentPhase: z.enum(["initial", "interview", "vision", "incubation", "journey"]).default("initial"),
  energyState: z.object({
    vibration: z.number().min(1).max(100).default(50),
    clarity: z.number().min(1).max(100).default(50),
    alignment: z.number().min(1).max(100).default(50)
  }).default({}),
  preferences: z.object({
    cosmicTheme: z.enum(["aurora", "nebula", "galaxy", "stardust"]).default("aurora"),
    interactionStyle: z.enum(["gentle", "direct", "playful", "profound"]).default("gentle")
  }).default({}),
  createdAt: z.date().default(() => new Date()),
  updatedAt: z.date().default(() => new Date())
});

// Cynthia conversation messages
export const conversationMessageSchema = z.object({
  id: z.string(),
  userId: z.string(),
  speaker: z.enum(["user", "cynthia"]),
  content: z.string(),
  messageType: z.enum(["greeting", "question", "insight", "guidance", "reflection"]).optional(),
  timestamp: z.date().default(() => new Date())
});

// Spiritual quests/experiences
export const questSchema = z.object({
  id: z.string(),
  userId: z.string(),
  title: z.string(),
  description: z.string(),
  type: z.enum(["reflection", "action", "creative", "healing", "exploration"]),
  status: z.enum(["available", "active", "completed", "locked"]).default("available"),
  rewards: z.object({
    vibrationBoost: z.number().default(0),
    clarityBoost: z.number().default(0),
    alignmentBoost: z.number().default(0)
  }).default({}),
  unlockConditions: z.array(z.string()).default([]),
  createdAt: z.date().default(() => new Date()),
  completedAt: z.date().optional()
});

// Environmental/world state
export const worldStateSchema = z.object({
  id: z.string(),
  userId: z.string(),
  currentZone: z.string().default("sanctuary"),
  weather: z.enum(["cosmic-calm", "aurora-dance", "star-shower", "nebula-flow"]).default("cosmic-calm"),
  timeOfDay: z.enum(["cosmic-dawn", "stellar-noon", "aurora-evening", "mystic-night"]).default("cosmic-dawn"),
  unlockedZones: z.array(z.string()).default(["sanctuary"]),
  ambientColors: z.object({
    primary: z.string().default("#8B5CF6"), // Cosmic purple
    secondary: z.string().default("#F59E0B"), // Golden amber
    accent: z.string().default("#10B981") // Emerald green
  }).default({}),
  updatedAt: z.date().default(() => new Date())
});

// Type exports using Zod inference
export type UserProfile = z.infer<typeof userProfileSchema>;
export type ConversationMessage = z.infer<typeof conversationMessageSchema>;
export type Quest = z.infer<typeof questSchema>;
export type WorldState = z.infer<typeof worldStateSchema>;

// Insert schemas for API validation
export const insertUserProfileSchema = userProfileSchema.omit({ 
  id: true, 
  createdAt: true, 
  updatedAt: true 
});

export const insertConversationMessageSchema = conversationMessageSchema.omit({ 
  id: true, 
  timestamp: true 
});

export const insertQuestSchema = questSchema.omit({ 
  id: true, 
  createdAt: true, 
  completedAt: true 
});

export const insertWorldStateSchema = worldStateSchema.omit({ 
  id: true, 
  updatedAt: true 
});

// Insert types
export type InsertUserProfile = z.infer<typeof insertUserProfileSchema>;
export type InsertConversationMessage = z.infer<typeof insertConversationMessageSchema>;
export type InsertQuest = z.infer<typeof insertQuestSchema>;
export type InsertWorldState = z.infer<typeof insertWorldStateSchema>;