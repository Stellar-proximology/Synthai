const { spawn } = require('child_process');

console.log('🌌 Starting YOU-N-I-VERSE consciousness simulation...');

// Start backend server
const backend = spawn('tsx', ['server/index.ts'], {
  stdio: 'inherit',
  env: { ...process.env, PORT: '3001' }
});

// Start frontend dev server 
const frontend = spawn('npx', ['vite', '--host', '0.0.0.0', '--port', '3000'], {
  cwd: 'client',
  stdio: 'inherit'
});

console.log('✨ YOU-N-I-VERSE servers starting...');
console.log('   Frontend: http://localhost:3000');
console.log('   Backend API: http://localhost:3001');

// Handle process cleanup
process.on('SIGINT', () => {
  console.log('\n🛑 Shutting down YOU-N-I-VERSE...');
  backend.kill();
  frontend.kill();
  process.exit(0);
});

backend.on('close', (code) => {
  console.log(`Backend process exited with code ${code}`);
});

frontend.on('close', (code) => {
  console.log(`Frontend process exited with code ${code}`);
});