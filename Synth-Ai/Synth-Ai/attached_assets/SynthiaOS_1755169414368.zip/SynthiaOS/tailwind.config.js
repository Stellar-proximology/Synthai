/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./client/index.html",
    "./client/src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: ["class"],
  theme: {
    extend: {
      colors: {
        cosmic: {
          purple: '#8B5CF6',
          amber: '#F59E0B',
          emerald: '#10B981',
          rose: '#F43F5E',
          indigo: '#6366F1'
        }
      },
      animation: {
        'cosmic-pulse': 'cosmic-pulse 3s ease-in-out infinite',
        'stellar-glow': 'stellar-glow 2s ease-in-out infinite alternate',
      },
      keyframes: {
        'cosmic-pulse': {
          '0%, 100%': { opacity: 0.7 },
          '50%': { opacity: 1 }
        },
        'stellar-glow': {
          '0%': { boxShadow: '0 0 20px rgba(139, 92, 246, 0.3)' },
          '100%': { boxShadow: '0 0 40px rgba(245, 158, 11, 0.5)' }
        }
      }
    },
  },
  plugins: [],
}