import { 
  UserProfile, 
  ConversationMessage, 
  Quest, 
  WorldState,
  InsertUserProfile,
  InsertConversationMessage,
  InsertQuest,
  InsertWorldState
} from "../shared/schema.js";

export interface IStorage {
  // User Profile operations
  createUserProfile(profile: InsertUserProfile): Promise<UserProfile>;
  getUserProfile(userId: string): Promise<UserProfile | null>;
  updateUserProfile(userId: string, updates: Partial<UserProfile>): Promise<UserProfile>;
  
  // Conversation operations
  addMessage(message: InsertConversationMessage): Promise<ConversationMessage>;
  getConversationHistory(userId: string, limit?: number): Promise<ConversationMessage[]>;
  
  // Quest operations
  createQuest(quest: InsertQuest): Promise<Quest>;
  getUserQuests(userId: string): Promise<Quest[]>;
  updateQuestStatus(questId: string, status: Quest['status']): Promise<Quest>;
  
  // World State operations
  createWorldState(worldState: InsertWorldState): Promise<WorldState>;
  getWorldState(userId: string): Promise<WorldState | null>;
  updateWorldState(userId: string, updates: Partial<WorldState>): Promise<WorldState>;
}

class MemStorage implements IStorage {
  private userProfiles: Map<string, UserProfile> = new Map();
  private messages: ConversationMessage[] = [];
  private quests: Map<string, Quest> = new Map();
  private worldStates: Map<string, WorldState> = new Map();

  // Helper to generate unique IDs
  private generateId(): string {
    return Math.random().toString(36).substring(2) + Date.now().toString(36);
  }

  async createUserProfile(profile: InsertUserProfile): Promise<UserProfile> {
    const id = this.generateId();
    const newProfile: UserProfile = {
      ...profile,
      id,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    this.userProfiles.set(id, newProfile);
    return newProfile;
  }

  async getUserProfile(userId: string): Promise<UserProfile | null> {
    return this.userProfiles.get(userId) || null;
  }

  async updateUserProfile(userId: string, updates: Partial<UserProfile>): Promise<UserProfile> {
    const existing = this.userProfiles.get(userId);
    if (!existing) {
      throw new Error("User profile not found");
    }

    const updated = {
      ...existing,
      ...updates,
      updatedAt: new Date()
    };

    this.userProfiles.set(userId, updated);
    return updated;
  }

  async addMessage(message: InsertConversationMessage): Promise<ConversationMessage> {
    const newMessage: ConversationMessage = {
      ...message,
      id: this.generateId(),
      timestamp: new Date()
    };
    
    this.messages.push(newMessage);
    return newMessage;
  }

  async getConversationHistory(userId: string, limit = 50): Promise<ConversationMessage[]> {
    return this.messages
      .filter(msg => msg.userId === userId)
      .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime())
      .slice(-limit);
  }

  async createQuest(quest: InsertQuest): Promise<Quest> {
    const id = this.generateId();
    const newQuest: Quest = {
      ...quest,
      id,
      createdAt: new Date()
    };
    
    this.quests.set(id, newQuest);
    return newQuest;
  }

  async getUserQuests(userId: string): Promise<Quest[]> {
    return Array.from(this.quests.values())
      .filter(quest => quest.userId === userId)
      .sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
  }

  async updateQuestStatus(questId: string, status: Quest['status']): Promise<Quest> {
    const existing = this.quests.get(questId);
    if (!existing) {
      throw new Error("Quest not found");
    }

    const updated = {
      ...existing,
      status,
      ...(status === 'completed' ? { completedAt: new Date() } : {})
    };

    this.quests.set(questId, updated);
    return updated;
  }

  async createWorldState(worldState: InsertWorldState): Promise<WorldState> {
    const id = this.generateId();
    const newWorldState: WorldState = {
      ...worldState,
      id,
      updatedAt: new Date()
    };
    
    this.worldStates.set(worldState.userId, newWorldState);
    return newWorldState;
  }

  async getWorldState(userId: string): Promise<WorldState | null> {
    return this.worldStates.get(userId) || null;
  }

  async updateWorldState(userId: string, updates: Partial<WorldState>): Promise<WorldState> {
    const existing = this.worldStates.get(userId);
    if (!existing) {
      throw new Error("World state not found");
    }

    const updated = {
      ...existing,
      ...updates,
      updatedAt: new Date()
    };

    this.worldStates.set(userId, updated);
    return updated;
  }
}

export const storage: IStorage = new MemStorage();