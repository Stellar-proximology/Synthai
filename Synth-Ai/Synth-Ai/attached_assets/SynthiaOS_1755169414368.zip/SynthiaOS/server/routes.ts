import express from "express";
import { storage } from "./storage.js";
import { 
  insertUserProfileSchema,
  insertConversationMessageSchema,
  insertQuestSchema,
  insertWorldStateSchema
} from "../shared/schema.js";

const router = express.Router();

// User Profile routes
router.post("/users", async (req, res) => {
  try {
    const profileData = insertUserProfileSchema.parse(req.body);
    const profile = await storage.createUserProfile(profileData);
    res.json(profile);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

router.get("/users/:userId", async (req, res) => {
  try {
    const profile = await storage.getUserProfile(req.params.userId);
    if (!profile) {
      return res.status(404).json({ error: "User profile not found" });
    }
    res.json(profile);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.patch("/users/:userId", async (req, res) => {
  try {
    const updates = req.body;
    const profile = await storage.updateUserProfile(req.params.userId, updates);
    res.json(profile);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Conversation routes
router.post("/conversations", async (req, res) => {
  try {
    const messageData = insertConversationMessageSchema.parse(req.body);
    const message = await storage.addMessage(messageData);
    res.json(message);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

router.get("/conversations/:userId", async (req, res) => {
  try {
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
    const messages = await storage.getConversationHistory(req.params.userId, limit);
    res.json(messages);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Quest routes
router.post("/quests", async (req, res) => {
  try {
    const questData = insertQuestSchema.parse(req.body);
    const quest = await storage.createQuest(questData);
    res.json(quest);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

router.get("/quests/:userId", async (req, res) => {
  try {
    const quests = await storage.getUserQuests(req.params.userId);
    res.json(quests);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.patch("/quests/:questId/status", async (req, res) => {
  try {
    const { status } = req.body;
    const quest = await storage.updateQuestStatus(req.params.questId, status);
    res.json(quest);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// World State routes
router.post("/world-state", async (req, res) => {
  try {
    const worldStateData = insertWorldStateSchema.parse(req.body);
    const worldState = await storage.createWorldState(worldStateData);
    res.json(worldState);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

router.get("/world-state/:userId", async (req, res) => {
  try {
    const worldState = await storage.getWorldState(req.params.userId);
    if (!worldState) {
      return res.status(404).json({ error: "World state not found" });
    }
    res.json(worldState);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.patch("/world-state/:userId", async (req, res) => {
  try {
    const updates = req.body;
    const worldState = await storage.updateWorldState(req.params.userId, updates);
    res.json(worldState);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Cynthia AI conversation endpoint with Tiny Llama integration
router.post("/cynthia/respond", async (req, res) => {
  try {
    const { userId, message } = req.body;
    
    // Get user profile and conversation history for context
    const userProfile = await storage.getUserProfile(userId);
    const conversationHistory = await storage.getConversationHistory(userId, 10);
    
    // Save user message first
    await storage.addMessage({
      userId,
      speaker: "user",
      content: message,
      messageType: "question"
    });
    
    // Build context for Cynthia agent
    const context = {
      userId,
      userProfile,
      conversationHistory: conversationHistory.map(msg => ({
        speaker: msg.speaker,
        content: msg.content,
        messageType: msg.messageType
      }))
    };
    
    // Get response from Cynthia agent (with Tiny Llama)
    const { cynthiaAgent } = await import("./agents/cynthia.js");
    const agentResponse = await cynthiaAgent.generateResponse(context);
    
    // Save Cynthia's response
    await storage.addMessage({
      userId,
      speaker: "cynthia",
      content: agentResponse.response,
      messageType: agentResponse.messageType
    });
    
    // Update user energy state if there's a shift
    if (agentResponse.energyShift && userProfile) {
      const newEnergyState = { ...userProfile.energyState };
      if (agentResponse.energyShift.vibration) {
        newEnergyState.vibration = Math.min(100, newEnergyState.vibration + agentResponse.energyShift.vibration);
      }
      if (agentResponse.energyShift.clarity) {
        newEnergyState.clarity = Math.min(100, newEnergyState.clarity + agentResponse.energyShift.clarity);
      }
      if (agentResponse.energyShift.alignment) {
        newEnergyState.alignment = Math.min(100, newEnergyState.alignment + agentResponse.energyShift.alignment);
      }
      
      await storage.updateUserProfile(userId, { energyState: newEnergyState });
    }
    
    // Create suggested quest if applicable
    let questCreated = null;
    if (agentResponse.questSuggestion && userProfile) {
      const questData = await cynthiaAgent.generateQuest(userId, agentResponse.questSuggestion, userProfile);
      questCreated = await storage.createQuest({
        userId,
        ...questData
      });
    }
    
    res.json({ 
      response: agentResponse.response,
      messageType: agentResponse.messageType,
      energyShift: agentResponse.energyShift,
      questCreated
    });
  } catch (error) {
    console.error("Cynthia response error:", error);
    res.status(500).json({ error: error.message });
  }
});

export default router;